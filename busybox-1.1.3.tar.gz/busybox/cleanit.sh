#!/bin/sh
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#  Copyright (c) 2008 HillRom Corporation
#
#  This software was developed by the HillRom Corporation.  This source code
#  or any derivative work should not be transferred or used in any fashion
#  other than for which it was originally intended without explicit written
#  consent from the HillRom Corportation.
#
#  Name:         cleanit.sh
#  Author:       R. Hume
#  Description:  Clean package in current directory.
#
#  Change Log
#  ---------------------------------------------------------------------------
#  12-29-2008 RH Initial creation
#
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

rm -rf busybox-1.1.3

