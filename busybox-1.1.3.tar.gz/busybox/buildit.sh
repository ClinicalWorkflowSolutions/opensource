#!/bin/sh
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#  Copyright (c) 2008 HillRom Corporation
#
#  This software was developed by the HillRom Corporation.  This source code
#  or any derivative work should not be transferred or used in any fashion
#  other than for which it was originally intended without explicit written
#  consent from the HillRom Corportation.
#
#  Name:         buildit.sh
#  Author:       R. Hume
#  Description:  Build package in current directory.
#
#  Change Log
#  ---------------------------------------------------------------------------
#  12-29-2008 RH Initial creation
#  12-10-2009 RL Patched to use gcc 4.3
#
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

tar -xjf busybox-1.1.3.tar.bz2

cp busybox.config busybox-1.1.3/.config

cd busybox-1.1.3

# RL: Patch for gcc 4.3 toolchain (built with 2.6.28 kernel headers)
if [ ${BUILD_TOOLCHAIN_NAME} = "arm-2009q1" ]; then
  patch -p1 < ../busybox_patches/busybox-1.1.3-fix-gcc-4.3.patch
fi

patch -p0 < ../busybox_patches/busybox-1-sortlibm.patch
patch -p1 < ../busybox_patches/busybox-1.1.3-getty-nobaud.patch
patch -p1 < ../busybox_patches/busybox-1.1.3-dev-root.patch
patch -p1 < ../busybox_patches/busybox-1.1.3-stty-2mbps-speed.patch 
patch -p1 < ../busybox_patches/busybox-1.1.3-udhcpc-options.patch
patch -p1 < ../busybox_patches/busybox-1.1.3-password.patch
patch -p1 < ../busybox_patches/busybox-1.1.3-binary-clientid.patch
patch -p1 < ../busybox_patches/busybox-1.1.3-MoveLogFile.patch
patch -p1 < ../busybox_patches/busybox-1.1.3-syslogd-prefix.patch


make oldconfig && \
make dep && \
make  && \
make install

RETVAL=$?
if [ $RETVAL != 0 ]; then
   echo "*** Failed to build Busybox. Halt."
   exit $RETVAL
fi
